/* Dendrai — Weebly script (risk loop). Upload to Assets, link in Settings > SEO > Footer Code. */
(function () {
  var STAGES = [
    { id: "sense", verb: "Sense", title: "Signal intake",
      body: "Live SEC EDGAR filings, FRED macro series, industry and threat feeds, internal KRIs and control data stream into one governed intake.",
      points: ["10-K, 10-Q, 8-K and XBRL financials", "Macro correlates and peer filings", "Control events and near-misses"] },
    { id: "score", verb: "Score", title: "Risk scoring and forecasting",
      body: "Deterministic models score, forecast and stress every risk, with forensic distress flags built in.",
      points: ["Beneish M-Score and Altman Z″-Score", "ARIMA ensemble and Monte Carlo forecasts", "Bear / Base / Bull and Grey Swan cascades"] },
    { id: "review", verb: "Review", title: "Human-in-the-loop gate",
      body: "The loop pauses. A named reviewer accepts, overrides with a written rationale, or escalates. AI can raise a risk, never quietly lower one.",
      points: ["Preparer → reviewer separation", "Override requires rationale", "Every decision recorded against the AI’s"] },
    { id: "scope", verb: "Scope", title: "Audit scope and plan",
      body: "Risks become risk-linked audit objectives, SOX scoping and a quarterly plan you can trace back to the evidence that justified it.",
      points: ["AI-scoped ICFR", "Risk-linked objectives by quarter", "Coverage gaps surfaced automatically"] },
    { id: "act", verb: "Act", title: "Management action plans",
      body: "Owners, dates and controls are assigned; control events and KRIs are monitored continuously, not at period end.",
      points: ["MAPs with owners and due dates", "Live control-health board", "Tiered stakeholder alert cascade"] },
    { id: "calibrate", verb: "Calibrate", title: "Closure and calibration",
      body: "Outcomes close the loop. Forecasts are backtested, drift is watched, and the next run starts smarter — with a board-ready Loop Report.",
      points: ["Backtest accuracy and PSI drift", "Hash-chained audit trail", "Board-ready Loop Report"] }
  ];

  var NS = "http://www.w3.org/2000/svg";
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function pt(r, deg) { var a = deg * Math.PI / 180; return [280 + r * Math.cos(a), 280 + r * Math.sin(a)]; }

  function svgMarkup(stages) {
    var s = '<svg viewBox="-50 -30 660 620" role="group" aria-label="Dendrai Intelligenza risk loop, ' + stages.length + ' stages">';
    [60, 110, 160, 210, 250].forEach(function (r) { s += '<circle class="ring" cx="280" cy="280" r="' + r + '"/>'; });
    for (var k = 0; k < 12; k++) { var a = pt(60, k * 30), b = pt(210, k * 30); s += '<line class="spoke" x1="' + a[0] + '" y1="' + a[1] + '" x2="' + b[0] + '" y2="' + b[1] + '"/>'; }
    for (var i = 0; i < 6; i++) { var p = pt(60, i * 60 - 60); s += '<circle class="dot dot--f" cx="' + p[0] + '" cy="' + p[1] + '" r="6"/>'; }
    for (i = 0; i < 12; i++) { p = pt(110, i * 30 - 75); s += '<circle class="dot' + (i % 2 ? ' dot--o' : '') + '" cx="' + p[0] + '" cy="' + p[1] + '" r="6"/>'; }
    for (i = 0; i < 18; i++) { p = pt(160, i * 20 - 80); s += '<circle class="dot' + (i % 3 === 0 ? ' dot--f' : i % 3 === 1 ? '' : ' dot--o') + '" cx="' + p[0] + '" cy="' + p[1] + '" r="5"/>'; }
    var C = 2 * Math.PI * 210;
    s += '<circle class="track" cx="280" cy="280" r="210" transform="rotate(-90 280 280)" stroke-dasharray="' + C + '" stroke-dashoffset="' + C + '"/>';
    s += '<circle class="core-ring" cx="280" cy="280" r="34"/><circle class="core" cx="280" cy="280" r="24"/>';
    stages.forEach(function (st, n) {
      var deg = -90 + n * (360 / stages.length), c = pt(210, deg), l = pt(258, deg);
      var dy = Math.sin(deg * Math.PI / 180) < -0.5 ? -8 : Math.sin(deg * Math.PI / 180) > 0.5 ? 22 : 6;
      var anchor = Math.cos(deg * Math.PI / 180) > 0.3 ? 'start' : Math.cos(deg * Math.PI / 180) < -0.3 ? 'end' : 'middle';
      s += '<g class="stage" data-i="' + n + '" tabindex="0" role="button" aria-label="Stage ' + (n + 1) + ': ' + esc(st.verb) + ' — ' + esc(st.title) + '">' +
        '<circle cx="' + c[0] + '" cy="' + c[1] + '" r="24"/>' +
        '<text class="num" x="' + c[0] + '" y="' + (c[1] + 5) + '">0' + (n + 1) + '</text>' +
        '<text x="' + l[0] + '" y="' + (l[1] + dy) + '" style="text-anchor:' + anchor + '">' + esc(st.verb) + '</text></g>';
    });
    return s + '</svg>';
  }

  function riskLoop(el, opts) {
    opts = opts || {};
    var stages = opts.stages || STAGES, active = Math.max(0, Math.min(stages.length - 1, opts.active || 0)), timer = null;
    el.classList.add("dd-loop");
    el.innerHTML = '<div class="dd-loop__figure">' + svgMarkup(stages) + '</div>' +
      '<div class="dd-loop__detail" aria-live="polite"></div>';
    var detail = el.querySelector(".dd-loop__detail"), track = el.querySelector(".track");
    var C = 2 * Math.PI * 210;
    function render() {
      var st = stages[active];
      [].forEach.call(el.querySelectorAll(".stage"), function (g, n) { g.classList.toggle("is-active", n === active); g.setAttribute("aria-pressed", n === active ? "true" : "false"); });
      track.setAttribute("stroke-dashoffset", String(C * (1 - (active + 1) / stages.length)));
      var steps = stages.map(function (_, n) { return '<button type="button" data-i="' + n + '" aria-label="Go to stage ' + (n + 1) + '"' + (n === active ? ' aria-current="step"' : '') + '></button>'; }).join("");
      detail.innerHTML = '<div class="dd-label">Stage 0' + (active + 1) + ' · ' + esc(st.verb) + '</div>' +
        '<h3>' + esc(st.title) + '</h3><p>' + esc(st.body) + '</p>' +
        '<ul>' + st.points.map(function (p) { return '<li>' + esc(p) + '</li>'; }).join("") + '</ul>' +
        '<div class="dd-loop__steps">' + steps + '</div>';
      if (opts.onChange) opts.onChange(active, st);
    }
    function go(n, user) { active = (n + stages.length) % stages.length; if (user) stop(); render(); }
    function stop() { if (timer) { clearInterval(timer); timer = null; } }
    el.addEventListener("click", function (e) { var t = e.target.closest("[data-i]"); if (t) go(+t.getAttribute("data-i"), true); });
    el.addEventListener("keydown", function (e) {
      var t = e.target.closest(".stage"); if (!t) return;
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); go(+t.getAttribute("data-i"), true); }
      if (e.key === "ArrowRight" || e.key === "ArrowDown") { e.preventDefault(); go(active + 1, true); el.querySelectorAll(".stage")[active].focus(); }
      if (e.key === "ArrowLeft" || e.key === "ArrowUp") { e.preventDefault(); go(active - 1, true); el.querySelectorAll(".stage")[active].focus(); }
    });
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (opts.autoplay && !reduce) timer = setInterval(function () { go(active + 1); }, opts.autoplay);
    render();
    return { setActive: function (n) { go(n, true); }, destroy: function () { stop(); el.innerHTML = ""; } };
  }

  window.Dendrai = { riskLoop: riskLoop, STAGES: STAGES };
  // Weebly: auto-start every <div data-dd-loop> on the page once it has loaded.
  function boot() {
    [].forEach.call(document.querySelectorAll("[data-dd-loop]"), function (el) {
      if (el.getAttribute("data-dd-ready")) return;
      el.setAttribute("data-dd-ready", "1");
      riskLoop(el, { active: +(el.getAttribute("data-active") || 0), autoplay: +(el.getAttribute("data-autoplay") || 0) || undefined });
    });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot); else boot();
})();
