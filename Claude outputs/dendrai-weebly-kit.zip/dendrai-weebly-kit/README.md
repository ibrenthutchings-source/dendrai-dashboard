# Dendrai on Weebly — setup guide

This kit turns the Dendrai home page design into pieces you can paste into Weebly. You don't need to write code; you'll copy files in and paste a few snippets.

**Requires the classic Weebly editor** (the one with **Theme → Edit HTML / CSS**). The newer Square Online editor doesn't allow custom code.

## What's in the kit

| Folder | What it is |
|---|---|
| `assets/dendrai-weebly.css` | All colours, fonts and layouts for the Dendrai blocks, plus light restyling of Weebly's own menu |
| `assets/dendrai-weebly.js` | Makes the interactive risk loop work |
| `assets/*.svg`, `*.png` | Logo files (SVG for the page, PNG for Weebly's logo uploader) |
| `sections/01…07-*.html` | One snippet per home page section, in page order |
| `sections/00-nav-optional.html` | A Dendrai nav bar, only for themes with no header of their own |
| `preview-in-weebly.html` | Open in a browser to see the finished page inside a Weebly-style theme |

## Step 1 — Prepare the theme (once)

1. In Weebly, go to **Theme**. Pick a plain theme with a simple header (fewer theme effects mean fewer clashes).
2. Click **Edit HTML / CSS**. Weebly asks you to **save the theme under a new name** before uploading files. Call it `Dendrai`.
3. In the left panel under **Assets**, click **+ → Upload File(s)** and upload everything in this kit's `assets` folder.
   Each file is then served at `/files/theme/<file name>` — the snippets already point there.
4. Click **Save**.

## Step 2 — Connect the stylesheet and script (once)

Go to **Settings → SEO**.

- **Header Code** — paste:
  ```html
  <link rel="stylesheet" href="/files/theme/dendrai-weebly.css">
  ```
- **Footer Code** — paste:
  ```html
  <script src="/files/theme/dendrai-weebly.js"></script>
  ```

Save.

## Step 3 — Logo and menu

- Click the site logo area in the editor → upload `dendrai-lockup-horizontal.png`.
- Pages and the menu stay Weebly's own. Create pages named **Intelligenza, The risk loop, Agent governance, Trust, About** and a **Request a pilot** page with a Weebly contact form.
- The stylesheet restyles Weebly's menu links to the Dendrai type and colours.

## Step 4 — Build the home page

1. On the Home page, open the page settings and choose the **No header** layout (so the theme's banner image doesn't sit above the hero).
2. From the Build panel, drag an **Embed Code** element onto the page. Click it → **Edit Custom HTML** → paste the full contents of `sections/01-hero.html`.
3. Add another Embed Code element below it and paste `02-why-dendrai.html`. Repeat in order through `06-proof-band.html`.
4. `07-footer.html` goes at the bottom of each page, or into the theme's footer if you prefer it on every page automatically.
5. **Publish.** The risk loop shows as a blank box in the editor and comes alive on the published site — Weebly doesn't run scripts while you edit.

## Step 5 — Point the links at real pages

The snippets use `href="#"` as placeholders. In each snippet, replace them with your page addresses, e.g. `href="/request-a-pilot.html"`, `href="/the-risk-loop.html"`.

## Editing text later

Each Embed Code element is plain HTML. Click it → **Edit Custom HTML** and change the words between the tags. Keep the `class="…"` parts as they are — they carry the design.

## Things to know

- **Switching themes deletes uploaded assets.** If you change theme, re-upload the `assets` files to the new theme.
- **Full-width bands.** Each section breaks out of the theme's content column so its background runs edge to edge. If a theme clips them, choose a theme with a full-width page layout.
- **Background.** The stylesheet sets the page background to parchment. To keep the theme's own background, delete the `body { background … }` line near the top of `dendrai-weebly.css` and re-upload.
- **Fonts** load from Google Fonts (Marcellus, Barlow Condensed, Roboto, Roboto Mono); nothing to install.
- **Other pages** reuse the same building blocks: copy a section snippet, change the words, keep the classes.
